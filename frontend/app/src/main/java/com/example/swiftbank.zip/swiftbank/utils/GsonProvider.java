package com.example.swiftbank.utils;

import com.example.swiftbank.api.dto.response.data.error.ErrorData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GsonProvider {
    private static Gson gson;

    public static Gson getGson() {
        if (gson == null) {
            gson = new GsonBuilder().
                    registerTypeAdapter(ErrorData.class, new ErrorDataDeserializer()).
                    create();
        }

        return gson;
    }
}

