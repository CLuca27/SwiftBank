package com.example.swiftbank.api.dto.response.data;

import com.google.gson.annotations.SerializedName;

public class LoginData {

    @SerializedName("user_id")
    private int userId;
    @SerializedName("email")
    private String email;

    @SerializedName("first_name")
    private String firstName;

    @SerializedName("last_name")
    private String lastName;

    public int getUserId() {
        return userId;
    }

    public String getEmail() {
        return email;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
}
