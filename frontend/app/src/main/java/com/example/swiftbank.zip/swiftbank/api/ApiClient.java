package com.example.swiftbank.api;

import com.example.swiftbank.api.services.AuthService;
import com.example.swiftbank.api.services.PlacesService;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    private static final String BASE_URL = "http://10.0.2.2:8618";

    private static Retrofit retrofit = null;

    //Implementam design pattern-ul singleton
    public static Retrofit getRetrofit(){

        if(retrofit == null)
        {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.level(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = new OkHttpClient.Builder().
                    addInterceptor(logging).
                    connectTimeout(30, TimeUnit.SECONDS).
                    readTimeout(30, TimeUnit.SECONDS).
                    writeTimeout(30, TimeUnit.SECONDS).
                    build();

            retrofit = new Retrofit.Builder().
                    client(client).
                    baseUrl(BASE_URL).
                    addConverterFactory(GsonConverterFactory.create()).
                    build();

        }

        return retrofit;
    }

    public static AuthService getAuthService() {
        return getRetrofit().create(AuthService.class);
    }
    public static PlacesService getPlacesService() {
        return getRetrofit().create(PlacesService.class);
    }


}
