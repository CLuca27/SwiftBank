package com.example.swiftbank.api.dto.response;

public class ApiResponse <T>{

    private boolean succes;

    private String message;

    private T data;

    public boolean isSucces() {
        return succes;
    }

    public String getMessage() {
        return message;
    }

    public T getData() {
        return data;
    }
}
